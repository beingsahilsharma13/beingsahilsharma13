// select all elements
const start = document.getElementById("start");
const quiz = document.getElementById("quiz");
const question = document.getElementById("question");
const choiceA = document.getElementById("A");
const choiceB = document.getElementById("B");
const choiceC = document.getElementById("C");
const choiceD = document.getElementById("D");
const counter = document.getElementById("counter");
const timeGauge = document.getElementById("timeGauge");
const progress = document.getElementById("progress");
const scoreDiv = document.getElementById("scoreContainer");

// create our questions
let questions = [
    {
        question : "Q.1 &nbsp;&nbsp; Delaration a pointer more than once may cause ____ ",
   
        choiceA : "Error",
        choiceB : "Abort",
        choiceC : "Trap",
        choiceD : "Null",
        correct : "C"
    },{
        question : "Q.2 &nbsp;&nbsp;Which one is not a correct variable type in C++?  ",
   
        choiceA : "float",
        choiceB : "real",
        choiceC : "double",
        choiceD : "int",
        correct : "B"
    },{
        question : "Q.3 &nbsp;&nbsp;Which operation is used as Logical 'AND' ?  ",
   
        choiceA : "Operator-&",
        choiceB : "Operator-||",
        choiceC : "Operator-&&",
        choiceD : "Operator +",
        correct : "C"
    },{
        question : "Q.4 &nbsp;&nbsp;An expression A.B in C++ means ____  ",
   
        choiceA : "A is member of object B",
        choiceB : "B is member of Object A",
        choiceC : "Product of A and B",
        choiceD : "None of these",
        correct : "B"
    },{
        question : "Q.5 &nbsp;&nbsp;A C++ code line ends with ___  ",
   
        choiceA : "A Semicolon (;)",
        choiceB : "A Fullstop(.)",
        choiceC : "A Comma (,)",
        choiceD : "A Slash (/)",
        correct : "A"
    },{
        question : "Q.6 &nbsp;&nbsp;______ function is used to allocate space for array in memory.   ",
   
        choiceA : "alloc()",
        choiceB : "malloc()",
        choiceC : "calloc())",
        choiceD : "realloc()",
        correct : "C"
    },{
        question : "Q.7 &nbsp;&nbsp;A ponter pointing to a variable that is not initialized is called ____ ",
   
        choiceA : "Void Pointer",
        choiceB : "Null Pointer",
        choiceC : "Empty Pointer",
        choiceD : "Wild Pointer",
        correct : "B"
    }
	,{
        question : "Q.8 &nbsp;&nbsp;Default constructor has ____ arguments. ",
   
        choiceA : "No argument",
        choiceB : "One argument",
        choiceC : "Two argument",
        choiceD : "None of the above",
        correct : "B"
    },{
        question : "Q.9 &nbsp;&nbsp;A class whose objects can not be created is known as _____  ",
   
        choiceA : "Absurd Class",
        choiceB : "Dead Class",
        choiceC : "Super Class",
        choiceD : "Abstract Class",
        correct : "D"
    }
	,{
        question : "Q.10 &nbsp;&nbsp;Which class allows only one object to be created.  ",
   
        choiceA : "Nuclear Family Class",
        choiceB : "Abstruct Class",
        choiceC : "Sigleton Class",
        choiceD : "Numero Uno Class",
        correct : "C"
    }
	,{
        question : "Q.11 &nbsp;&nbsp;Reusability of code in C++ is achieved through ____ ",
   
        choiceA : "Polymorphism",
        choiceB : "Inheritance",
        choiceC : "Encapsulation",
        choiceD : "Both A and B",
        correct : "B"
    },{
        question : "Q.12 &nbsp;&nbsp;In CPP, members of a class are ______ by default. ",
   
        choiceA : "Public",
        choiceB : "Private",
        choiceC : "Protected",
        choiceD : "Static",
        correct : "B"
    }
	,{
        question : "Q.13 &nbsp;&nbsp;In C++ Program, inline fuctions are expanded during ____ ",
   
        choiceA : "Run Time",
        choiceB : "Compile Time",
        choiceC : "Coding Time",
        choiceD : "Debug Time",
        correct : "A"
    },{
        question : "Q.14 &nbsp;&nbsp;To perform file input / output operation in C++, we must include which header file ? ",
   
        choiceA : "fiostream",
        choiceB : "ifstream",
        choiceC : "ofstream",
        choiceD : "fstream",
        correct : "D"
    },{
        question : "Q.15 &nbsp;&nbsp;An exception in C++ can be generated using which keywords. ",
   
        choiceA : "thrown",
        choiceB : "threw",
        choiceC : "throw",
        choiceD : "throws",
        correct : "C"
    }
];


// create some variables

const lastQuestion = questions.length - 1;
let runningQuestion = 0;
let count = 0;
const questionTime = 10; // 10s
const gaugeWidth = 150; // 150px
const gaugeUnit = gaugeWidth / questionTime;
let TIMER;
let score = 0;

// render a question
function renderQuestion(){
    let q = questions[runningQuestion];
    
    question.innerHTML = "<p>"+ q.question +"</p>";

    choiceA.innerHTML = q.choiceA;
    choiceB.innerHTML = q.choiceB;
    choiceC.innerHTML = q.choiceC;
    choiceD.innerHTML = q.choiceD;
}

start.addEventListener("click",startQuiz);

// start quiz
function startQuiz(){
    start.style.display = "none";
    renderQuestion();
    quiz.style.display = "block";
    renderProgress();
    renderCounter();
    TIMER = setInterval(renderCounter,1000); // 1000ms = 1s
}

// render progress
function renderProgress(){
    for(let qIndex = 0; qIndex <= lastQuestion; qIndex++){
        progress.innerHTML += "<div class='prog' id="+ qIndex +"></div>";
    }
}

// counter render

function renderCounter(){
    if(count <= questionTime){
        counter.innerHTML = count;
        timeGauge.style.width = count * gaugeUnit + "px";
        count++
    }else{
        count = 0;
        // change progress color to red
        answerIsWrong();
        if(runningQuestion < lastQuestion){
            runningQuestion++;
            renderQuestion();
        }else{
            // end the quiz and show the score
            clearInterval(TIMER);
            scoreRender();
        }
    }
}

// checkAnwer

function checkAnswer(answer){
    if( answer == questions[runningQuestion].correct){
        // answer is correct
        score++;
        // change progress color to green
        answerIsCorrect();
    }else{
        // answer is wrong
        // change progress color to red
        answerIsWrong();
    }
    count = 0;
    if(runningQuestion < lastQuestion){
        runningQuestion++;
        renderQuestion();
    }else{
        // end the quiz and show the score
        clearInterval(TIMER);
        scoreRender();
    }
}

// answer is correct
function answerIsCorrect(){
    document.getElementById(runningQuestion).style.backgroundColor = "#0f0";
}

// answer is Wrong
function answerIsWrong(){
    document.getElementById(runningQuestion).style.backgroundColor = "#f00";
}

// score render
function scoreRender(){
    scoreDiv.style.display = "block";
    
    // calculate the amount of question percent answered by the user
    const scorePerCent = Math.round(100 * score/questions.length);
    
    // choose the image based on the scorePerCent
    let img = (scorePerCent >= 80) ? "img/5.png" :
              (scorePerCent >= 60) ? "img/4.png" :
              (scorePerCent >= 40) ? "img/3.png" :
              (scorePerCent >= 20) ? "img/2.png" :
              "img/1.png";
    
    scoreDiv.innerHTML = "<img src="+ img +">";
    scoreDiv.innerHTML += "<p>"+ scorePerCent +"%</p>";
		if(window.confirm("Your Score is"+scorePerCent+"%"+"\n\nThanks for Playing!!")){
	window.location.href="cpp.html";
	}
	else{
	window.location.href="Welcome.html";
	};
}





















