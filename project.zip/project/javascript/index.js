function error()
{
var name=document.f1.n1.value;
var alpha= /^[a-z A-Z]+$/
if(name==""){
		alert("Please !!! Enter Your Name First and Click on I'm Done");
		return false;
}

}

function error1()
{
var name=document.f1.n1.value;
var alpha= /^[a-z A-Z]+$/
if(name==""){
		document.getElementById("ns").innerHTML="Please!! Enter your Name First";
		document.getElementById("ns").style.color="red";
		document.f1.n1.focus();
		document.f1.n1.style.border="2px groove Red";
	
		return false;
}
else{
		if(!(name.match(alpha))){
		document.getElementById("ns").innerHTML="Name must contains alphabets";
		document.getElementById("ns").style.color="red";
		document.f1.n1.focus();
		document.f1.n1.style.border="2px groove Red";
		return false;
		}
		
		sessionStorage.setItem("user",name);
}
}
function welcome(){
var nname=sessionStorage.getItem("user");
document.getElementById("uname").innerHTML=nname;
document.getElementById("login").innerHTML=nname;
}
function log(){
var nname=sessionStorage.getItem("user");
if(nname==null){
if(window.confirm("Please!! Login First \n\n Click OK to Login")){
	window.location.href="index.html";
	}
	else{
	window.location.href="index.html";
	}
}else{
document.getElementById("uname").innerHTML=nname;
document.getElementById("login").innerHTML=nname;
}
}